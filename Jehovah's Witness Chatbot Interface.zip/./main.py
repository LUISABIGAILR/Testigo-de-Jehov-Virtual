import logging

from flask import Flask, render_template, session
from flask_session import Session
from gunicorn.app.base import BaseApplication

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# Configuring server-side session
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

from abilities import llm
from flask import request, jsonify

@app.route("/")
def root_route():
    return render_template("template.html")

@app.route("/send_message", methods=['POST'])
def send_message():
    user_message = request.json['message']
    if 'history' not in session:
        session['history'] = []
    session['history'].append({"user": user_message})
    if len(session['history']) > 10:
        session['history'] = session['history'][-10:]
    
    prompt = f"""You are a knowledgeable and experienced Jehovah's Witness who provides thoughtful, respectful answers based on Biblical teachings and official JW publications. 
    Always maintain a kind and helpful tone, similar to how a Witness would speak during ministry. Include relevant Bible verses when appropriate.
    When discussing doctrinal matters, reference information from jw.org and official Watchtower publications.
    
    Previous conversation:
    {" ".join([f"user: {msg.get('user', '')} witness: {msg.get('bot', '')}" for msg in session['history']])}
    
    User's question: {user_message}
    
    Provide a response as a Jehovah's Witness would, including Biblical references when relevant."""
    
    response = llm(
        prompt=prompt,
        response_schema={
            "type": "object",
            "properties": {
                "response": {
                    "type": "string",
                    "description": "The Jehovah's Witness response to the user's question"
                }
            }
        },
        model="gpt-4o",
        temperature=0.7
    )["response"]
    
    session['history'].append({"bot": response})
    return jsonify({"message": response})


class StandaloneApplication(BaseApplication):
    def __init__(self, app, options=None):
        self.application = app
        self.options = options or {}
        super().__init__()

    def load_config(self):
        config = {
            key: value
            for key, value in self.options.items()
            if key in self.cfg.settings and value is not None
        }
        for key, value in config.items():
            self.cfg.set(key.lower(), value)

    def load(self):
        return self.application


# Do not remove the main function while updating the app.
if __name__ == "__main__":
    options = {"bind": "%s:%s" % ("0.0.0.0", "8080"), "workers": 4, "loglevel": "info"}
    StandaloneApplication(app, options).run()
