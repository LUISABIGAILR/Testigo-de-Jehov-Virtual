document.addEventListener('DOMContentLoaded', (event) => {
    const sendButton = document.getElementById('sendButton');
    const userInput = document.getElementById('userInput');
    const lastQuestionText = document.getElementById('lastQuestionText');
    const currentResponseText = document.getElementById('currentResponseText');

    const sendMessage = () => {
        const userText = userInput.value;
        if (userText.trim() !== '') {
            // Update last question
            lastQuestionText.textContent = userText;
            
            // Clear current response and show typing indicator
            currentResponseText.textContent = 'Typing...';
            userInput.value = ''; // Clear input after sending

            fetch('/send_message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: userText }),
            })
            .then(response => response.json())
            .then(data => {
                // Update current response
                currentResponseText.textContent = data.message;
            })
            .catch((error) => {
                currentResponseText.textContent = 'Error al procesar la respuesta';
                console.error('Error:', error);
            });
        }
    };

    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
            e.preventDefault();
        }
    });
});
